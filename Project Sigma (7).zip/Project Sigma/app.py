from flask import Flask, render_template, request, redirect, url_for
from dao import Database, GebruikerDAO

app = Flask(__name__, template_folder='.', static_folder='.')

password1 = "7002melliW"
password2 = password1[::-1]

app = Flask(__name__)

# Maak connectie met database
db = Database(host="localhost", database="mydb", user="root", password=password2)
gebruiker_dao = GebruikerDAO(db)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        naam = request.form.get('naam')
        email = request.form.get('email')
        wachtwoord = request.form.get('wachtwoord')
        straat = request.form.get('straat')
        straatnr = request.form.get('straatnr')
        postcode = request.form.get('postcode')
        gemeente = request.form.get('gemeente')
        
        gebruiker_dao.create_gebruiker(
            naam, "onbekend", email, wachtwoord, straat, postcode, straatnr, gemeente
        )

        return redirect(url_for('startscherm'))

    return render_template("Register.html")

@app.route('/startscherm')
def startscherm():
    return render_template("startscherm.html")

if __name__ == '__main__':
    app.run(debug=True)
